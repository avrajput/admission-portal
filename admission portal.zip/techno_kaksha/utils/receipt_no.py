from models.payment import Payment
from models.student import Student
from models.db import db


def generate_receipt_no(student_roll_no):
    student = Student.query.filter_by(roll_no=student_roll_no).first()

    if not student:
        return "INVALID"

    branch_id = student.user.branch_id if student.user else "00"

    # COUNT PAYMENTS FOR THIS BRANCH
    count = db.session.query(Payment).join(Student).filter(
        Student.branch_id == branch_id
    ).count()

    next_no = count + 1

    return f"TK-BR{branch_id}-{str(next_no).zfill(4)}"