from datetime import datetime
from models.db import db
from models.student import Student
from models.branch import Branch
from models.course import Course

def generate_roll_no(branch_id, course_id):
    # Fetch branch and course
    branch = Branch.query.get(branch_id)
    course = Course.query.get(course_id)
    
    if not branch or not course:
        raise ValueError("Branch or Course not found")
    
    # Branch code map (same as in routes)
    branch_code_map = {
        "Saket": "SK", 
        "Devli": "DEV", 
        "South Extension": "SOUTHEX"
    }
    branch_code = branch_code_map.get(branch.name, "GEN")
    
    # Dynamic year
    year = str(datetime.now().year)[-2:]
    course_initials = ''.join([word[0] for word in course.name.upper().split()])[:2]
    prefix = f"TK{year}{branch_code}{course_initials}"
    
    # Query max existing roll_no for this branch/course with this prefix
    max_roll = db.session.query(db.func.max(Student.roll_no)).filter(
        Student.roll_no.like(prefix + '%'),
        Student.branch_id == branch_id,
        Student.course_id == course_id
    ).scalar()
    
    if max_roll is None:
        suffix = "001"
    else:
        # Parse suffix (last 3 digits)
        try:
            num = int(max_roll[-3:]) + 1
            suffix = f"{num:03d}"
        except ValueError:
            suffix = "001"
    
    return f"{prefix}-{suffix}"
