from datetime import datetime
from flask import session

def get_current_time():
    fake_time = session.get("fake_time")

    if fake_time:
        return datetime.strptime(fake_time, "%Y-%m-%d")

    return datetime.now()