from models.attendance import Attendance
from models.student import Student
from models.class_model import Class
from models.user import db
from datetime import date


# Prevent duplicate attendance
def attendance_exists(student_roll_no, class_id):
    return Attendance.query.filter_by(
        student_roll_no=student_roll_no,
        class_id=class_id,
        date=date.today()
    ).first()


# Mark single attendance
def mark_single_attendance(student_id, class_id, status):
    if attendance_exists(student_id, class_id):
        return False, "Already marked today"

    attendance = Attendance(
        student_id=student_id,
        class_id=class_id,
        status=status
    )

    db.session.add(attendance)
    return True, "Marked"


# Bulk attendance (MAIN LOGIC)
def mark_bulk_attendance(class_id, attendance_data):

    today = date.today()

    for student_id, status in attendance_data.items():

        existing = Attendance.query.filter_by(
            student_id=student_id,
            class_id=class_id,
            date=today
        ).first()

        if existing:
            # UPDATE instead of duplicate
            existing.status = status
        else:
            record = Attendance(
                student_id=student_id,
                class_id=class_id,
                date=today,
                status=status
            )
            db.session.add(record)

    db.session.commit()

    return True


# Get students for a class (IMPORTANT FIX)
def get_students_for_class(class_id):
    # For now: return all students (we will fix later with batch system)
    return Student.query.all()


# Attendance percentage (future dashboard)
def calculate_attendance_percentage(student_id):
    total = Attendance.query.filter_by(student_id=student_id).count()

    present = Attendance.query.filter_by(
        student_id=student_id,
        status="present"
    ).count()

    if total == 0:
        return 0

    return round((present / total) * 100, 2)