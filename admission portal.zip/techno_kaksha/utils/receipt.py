from io import BytesIO
import os

from reportlab.lib import colors
from reportlab.lib.pagesizes import A5
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle


def _add_watermark(canvas_obj, _doc):
    logo_path = "static/logo.png"
    if os.path.exists(logo_path):
        canvas_obj.saveState()
        canvas_obj.setFillAlpha(0.025)
        page_w, page_h = _doc.pagesize
        wm_w = 80 * mm
        wm_h = 80 * mm
        canvas_obj.drawImage(
            logo_path,
            x=(page_w - wm_w) / 2,
            y=(page_h - wm_h) / 2 - (8 * mm),
            width=wm_w,
            height=wm_h,
            preserveAspectRatio=True,
            mask="auto",
        )
        canvas_obj.restoreState()


def _currency(value):
    try:
        return f"Rs. {float(value):,.2f}"
    except Exception:
        return "Rs. 0.00"


def generate_receipt(payment, student, fee):
    buffer = BytesIO()

    doc = SimpleDocTemplate(
        buffer,
        pagesize=A5,
        leftMargin=12 * mm,
        rightMargin=12 * mm,
        topMargin=10 * mm,
        bottomMargin=10 * mm,
    )
    content_w = doc.width

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "ReceiptTitle",
        parent=styles["Heading1"],
        fontName="Helvetica-Bold",
        fontSize=17,
        textColor=colors.white,
        leading=20,
    )
    subtitle_style = ParagraphStyle(
        "ReceiptSubtitle",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=9,
        textColor=colors.white,
    )
    section_heading = ParagraphStyle(
        "SectionHeading",
        parent=styles["Heading4"],
        fontName="Helvetica-Bold",
        fontSize=10,
        textColor=colors.HexColor("#0b4f6c"),
        spaceAfter=4,
    )
    label_style = ParagraphStyle(
        "Label",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=9,
        textColor=colors.HexColor("#374151"),
    )
    value_style = ParagraphStyle(
        "Value",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=9,
        textColor=colors.HexColor("#111827"),
    )
    footer_style = ParagraphStyle(
        "Footer",
        parent=styles["Normal"],
        fontName="Helvetica-Oblique",
        fontSize=8,
        textColor=colors.HexColor("#6b7280"),
        alignment=1,
    )

    branch_name = (
        student.branch.name
        if getattr(student, "branch", None) is not None
        else (
            student.user.branch.name
            if getattr(student, "user", None) is not None and getattr(student.user, "branch", None) is not None
            else "-"
        )
    )

    payment_date = payment.date.strftime("%d-%m-%Y %I:%M %p") if payment.date else "-"
    payment_type = (payment.payment_type or "-").upper()

    elements = []

    header = Table(
        [
            [
                Paragraph("TECHNO KAKSHA", title_style),
                Paragraph("PAYMENT RECEIPT", subtitle_style),
            ]
        ],
        colWidths=[content_w * 0.62, content_w * 0.38],
    )
    header.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#0b4f6c")),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("ALIGN", (1, 0), (1, 0), "RIGHT"),
                ("LEFTPADDING", (0, 0), (-1, -1), 10),
                ("RIGHTPADDING", (0, 0), (-1, -1), 10),
                ("TOPPADDING", (0, 0), (-1, -1), 8),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
                ("BOX", (0, 0), (-1, -1), 0.6, colors.HexColor("#0b4f6c")),
            ]
        )
    )
    elements.append(header)
    elements.append(Spacer(1, 7))

    meta_block = Table(
        [
            [Paragraph("Receipt No", label_style), Paragraph(str(payment.receipt_no or "-"), value_style)],
            [Paragraph("Date", label_style), Paragraph(payment_date, value_style)],
            [Paragraph("Payment Type", label_style), Paragraph(payment_type, value_style)],
            [Paragraph("Manual Receipt No", label_style), Paragraph(str(payment.manual_receipt_no or "-"), value_style)],
        ],
        colWidths=[content_w * 0.28, content_w * 0.72],
    )
    meta_block.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#f8fafc")),
                ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#d1d5db")),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ]
        )
    )
    elements.append(meta_block)
    elements.append(Spacer(1, 8))

    elements.append(Paragraph("Student Information", section_heading))
    student_info = Table(
        [
            [
                Paragraph("Student Name", label_style),
                Paragraph(
                    student.full_name
                    or (student.user.name if getattr(student, "user", None) else "-"),
                    value_style,
                ),
            ],
            [Paragraph("Roll Number", label_style), Paragraph(student.roll_no or "-", value_style)],
            [Paragraph("Branch", label_style), Paragraph(branch_name, value_style)],
            [Paragraph("Course", label_style), Paragraph(student.course.name if getattr(student, "course", None) else "-", value_style)],
        ],
        colWidths=[content_w * 0.28, content_w * 0.72],
    )
    student_info.setStyle(
        TableStyle(
            [
                ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#d1d5db")),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ]
        )
    )
    elements.append(student_info)
    elements.append(Spacer(1, 10))

    elements.append(Paragraph("Payment Breakdown", section_heading))
    breakdown = Table(
        [
            [
                Paragraph("Description", label_style),
                Paragraph("Amount", label_style),
            ],
            [
                Paragraph(f"{payment_type} fee payment", value_style),
                Paragraph(_currency(payment.amount), value_style),
            ],
        ],
        colWidths=[content_w * 0.74, content_w * 0.26],
    )
    breakdown.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#eaf4f8")),
                ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#d1d5db")),
                ("ALIGN", (1, 0), (1, -1), "RIGHT"),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                ("TOPPADDING", (0, 0), (-1, -1), 6),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ]
        )
    )
    elements.append(breakdown)
    elements.append(Spacer(1, 10))

    totals = Table(
        [
            [Paragraph("Total Fee", label_style), Paragraph(_currency(fee.total_fee), value_style)],
            [Paragraph("Total Paid", label_style), Paragraph(_currency(fee.paid_amount), value_style)],
            [Paragraph("Balance Pending", label_style), Paragraph(_currency(fee.pending_amount), value_style)],
        ],
        colWidths=[content_w * 0.36, content_w * 0.24],
    )
    totals.setStyle(
        TableStyle(
            [
                ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#d1d5db")),
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#f8fafc")),
                ("ALIGN", (1, 0), (1, -1), "RIGHT"),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                ("TOPPADDING", (0, 0), (-1, -1), 6),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ]
        )
    )

    sign_block = Table(
        [
            [Paragraph("Authorized Signature", label_style)],
            [Paragraph("<br/><br/>__________________________", value_style)],
        ],
        colWidths=[content_w * 0.40],
    )
    sign_block.setStyle(
        TableStyle(
            [
                ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("BOX", (0, 0), (-1, -1), 0.25, colors.HexColor("#d1d5db")),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                ("TOPPADDING", (0, 0), (-1, -1), 8),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
            ]
        )
    )

    footer_row = Table([[totals, sign_block]], colWidths=[content_w * 0.60, content_w * 0.40])
    footer_row.setStyle(
        TableStyle(
            [
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 0),
                ("RIGHTPADDING", (0, 0), (-1, -1), 0),
            ]
        )
    )
    elements.append(footer_row)
    elements.append(Spacer(1, 10))

    elements.append(
        Paragraph(
            "This is a computer-generated receipt and does not require a physical signature.",
            footer_style,
        )
    )

    doc.build(elements, onFirstPage=_add_watermark)
    buffer.seek(0)
    return buffer
