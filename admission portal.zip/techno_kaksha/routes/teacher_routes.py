from flask import Blueprint, render_template, request, flash
from flask_login import login_required, current_user
from datetime import date
from utils.attendance_service import (
    mark_bulk_attendance,
    get_students_for_class
)
from models.student_class import StudentClass
from models.student import Student
from models.class_model import Class
from models.teacher import Teacher
from models.attendance import Attendance
from services.attendance_analytics import get_student_attendance_summary

teacher_bp = Blueprint("teacher", __name__, url_prefix="/teacher")


@teacher_bp.route("/attendance/<int:class_id>", methods=["GET", "POST"])
@login_required
def mark_attendance(class_id):

    if current_user.role != "teacher":
        return "Unauthorized"

    teacher = Teacher.query.filter_by(user_id=current_user.id).first()

    if not teacher:
        return "Teacher not found"

    class_obj = Class.query.get(class_id)

    if not class_obj or class_obj.teacher_id != teacher.id:
        return "Unauthorized access"

    mappings = StudentClass.query.filter_by(class_id=class_id).all()

    students = Student.query.filter(
        Student.id.in_([m.student_id for m in mappings])
    ).all()

    today = date.today()

    if request.method == "POST":
        attendance_data = {}

        for student in students:
            status = request.form.get(f"student_{student.id}")
            attendance_data[student.id] = status

        mark_bulk_attendance(class_id, attendance_data)

        flash("Attendance submitted", "success")

    # GET TODAY'S ATTENDANCE (for UI)
    existing_attendance = {
        a.student_id: a.status
        for a in Attendance.query.filter_by(
            class_id=class_id,
            date=today
        ).all()
    }

    return render_template(
        "teacher/attendance.html",
        students=students,
        existing_attendance=existing_attendance,
        today=today,
        class_obj=class_obj
    )

@teacher_bp.route("/dashboard")
@login_required
def teacher_dashboard():
    if current_user.role != "teacher":
        return "Unauthorized"

    teacher = Teacher.query.filter_by(user_id=current_user.id).first()

    if not teacher:
        return "Teacher profile not found"

    classes = Class.query.filter_by(teacher_id=teacher.id).all()

    # Add student count to each class
    for c in classes:
        c.student_count = StudentClass.query.filter_by(class_id=c.id).count()

    total_students = 0
    class_ids = [c.id for c in classes]
    if class_ids:
        total_students = StudentClass.query.filter(StudentClass.class_id.in_(class_ids)).count()

    return render_template(
        "teacher/dashboard.html",
        classes=classes,
        teacher=teacher,
        total_students=total_students
    )

@teacher_bp.route("/class/<int:class_id>")
@login_required
def class_view(class_id):

    if current_user.role != "teacher":
        return "Unauthorized"

    teacher = Teacher.query.filter_by(user_id=current_user.id).first()

    if not teacher:
        return "Teacher not found"

    class_obj = Class.query.get(class_id)

    # SECURITY CHECK
    if not class_obj or class_obj.teacher_id != teacher.id:
        return "Unauthorized access"

    # GET STUDENTS
    mappings = StudentClass.query.filter_by(class_id=class_id).all()

    students_list = Student.query.filter(
        Student.id.in_([m.student_id for m in mappings])
    ).all()

    # ADD ANALYTICS
    student_data = []
    total_percentage = 0

    for s in students_list:
        summary = get_student_attendance_summary(s.id, class_id)
        student_data.append({
            "student": s,
            "summary": summary
        })
        total_percentage += summary["percentage"]

    # Calculate average attendance
    attendance_avg = round(total_percentage / len(students_list)) if students_list else 0

    return render_template(
        "teacher/class_view.html",
        class_obj=class_obj,
        students=student_data,
        attendance_avg=attendance_avg
    )

@teacher_bp.route("/attendance-history/<int:class_id>")
@login_required
def attendance_history(class_id):

    if current_user.role != "teacher":
        return "Unauthorized"

    teacher = Teacher.query.filter_by(user_id=current_user.id).first()

    class_obj = Class.query.get(class_id)

    # SECURITY CHECK
    if not class_obj or class_obj.teacher_id != teacher.id:
        return "Unauthorized access"

    records = Attendance.query.filter_by(class_id=class_id)\
        .order_by(Attendance.date.desc())\
        .all()

    return render_template(
        "teacher/attendance_history.html",
        records=records,
        class_obj=class_obj
    )