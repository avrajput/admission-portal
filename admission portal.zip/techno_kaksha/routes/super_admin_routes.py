from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from flask_login import login_required, current_user
from models.db import db
from models.branch import Branch
from models.user import User
from models.course import Course, Subject
from werkzeug.security import generate_password_hash
from services.super_admin_analytics import get_super_admin_stats, get_branch_wise_data, get_branch_insights, get_monthly_revenue
from models.student import Student



super_admin_bp = Blueprint("super_admin", __name__, url_prefix="/super-admin")



def super_admin_required():
    return current_user.role == "super_admin"


# ================= DASHBOARD =================
@super_admin_bp.route("/dashboard")
@login_required
def dashboard():

    if current_user.role != "super_admin":
        return "Unauthorized"

    stats = get_super_admin_stats()
    branch_data = get_branch_wise_data()

    top_branch, low_branch = get_branch_insights()
    branches = Branch.query.all()

    monthly_revenue = get_monthly_revenue()

    labels = [b["branch"].name for b in branch_data]
    student_values = [b["students"] for b in branch_data]
    revenue_values = [b["revenue"] for b in branch_data]

    return render_template(
        "super_admin/dashboard.html",
        stats=stats,
        branch_data=branch_data,
        labels=labels,
        student_values=student_values,
        revenue_values=revenue_values,
        top_branch=top_branch,
        low_branch=low_branch,
        branches=branches,
        monthly_revenue=monthly_revenue
    )


# ================= ADD BRANCH =================
@super_admin_bp.route("/add-branch", methods=["GET", "POST"])
@login_required
def add_branch():
    if not super_admin_required():
        return "Unauthorized"

    if request.method == "POST":
        name = request.form["name"]
        location = request.form["location"]

        branch = Branch(name=name, location=location)
        db.session.add(branch)
        db.session.commit()

        flash("Branch created", "success")

    branches = Branch.query.all()

    return render_template("super_admin/add_branch.html", branches=branches)


# ================= ADD ADMIN =================
@super_admin_bp.route("/add-admin", methods=["GET", "POST"])
@login_required
def add_admin():
    if not super_admin_required():
        return "Unauthorized"

    branches = Branch.query.all()

    if request.method == "POST":
        name = request.form["name"]
        email = request.form["email"]
        password = request.form["password"]
        branch_id = request.form["branch_id"]

        # Check if email already exists
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            flash("Email already exists. Please use a different email.", "error")
            return render_template("super_admin/add_admin.html", branches=branches)

        user = User(
            name=name,
            email=email,
            password=generate_password_hash(password),
            role="admin",
            branch_id=branch_id
        )

        db.session.add(user)
        db.session.commit()

        flash("Admin created successfully!", "success")
        return redirect(url_for("super_admin.manage_admins"))

    return render_template("super_admin/add_admin.html", branches=branches)


# ================= ADD COURSE =================
@super_admin_bp.route("/add-course", methods=["GET", "POST"])
@login_required
def add_course():
    if current_user.role != "super_admin":
        return "Unauthorized"

    branches = Branch.query.order_by(Branch.name.asc()).all()
    courses = Course.query.order_by(Course.name.asc()).all()

    if request.method == "POST":
        name = request.form["name"]
        branch_id = request.form.get("branch_id")
    
        existing = Course.query.filter_by(name=name, branch_id=branch_id).first()

        if existing:
            flash("Course already exists for this branch", "warning")
            return redirect(url_for("super_admin.add_course"))

        course = Course(
            name=name,
            duration=request.form["duration"],
            total_fee=request.form["fee"],
            branch_id=branch_id
        )

        db.session.add(course)
        db.session.commit()
        flash("Course added successfully", "success")
        return redirect(url_for("super_admin.add_course"))

    return render_template("super_admin/add_course.html", courses=courses, branches=branches)


# ================= ADD SUBJECT =================
@super_admin_bp.route("/add-subject", methods=["GET", "POST"])
@login_required
def add_subject():
    if current_user.role != "super_admin":
        return "Unauthorized"

    courses = Course.query.order_by(Course.name.asc()).all()
    subjects = Subject.query.order_by(Subject.name.asc()).all()

    if request.method == "POST":
        action = request.form.get("action", "add_subject")

        if action == "add_subject":
            name = request.form["name"].strip()

            existing = Subject.query.filter_by(name=name).first()
            if existing:
                flash("Subject already exists", "warning")
                return redirect(url_for("super_admin.add_subject"))

            subject = Subject(name=name)
            db.session.add(subject)
            db.session.commit()

            flash("Subject added", "success")
            return redirect(url_for("super_admin.add_subject"))

        if action == "assign_subject":
            course_id = request.form.get("course_id")
            subject_id = request.form.get("subject_id")

            course = Course.query.get(course_id)
            subject = Subject.query.get(subject_id)

            if not course or not subject:
                flash("Invalid course or subject", "danger")
                return redirect(url_for("super_admin.add_subject"))

            if subject in course.subjects:
                flash("Subject already assigned to this course", "warning")
                return redirect(url_for("super_admin.add_subject"))

            course.subjects.append(subject)
            db.session.commit()

            flash("Subject assigned to course", "success")
            return redirect(url_for("super_admin.add_subject"))

    return render_template(
        "super_admin/add_subject.html",
        courses=courses,
        subjects=subjects
    )


# ================= ASSIGN SUBJECT =================
@super_admin_bp.route("/assign-subject", methods=["GET", "POST"])
@login_required
def assign_subject():
    if current_user.role != "super_admin":
        return "Unauthorized"

    return redirect(url_for("super_admin.add_subject"))


@super_admin_bp.route("/branches")
@login_required
def manage_branches():
    if current_user.role != "super_admin":
        return "Unauthorized"

    branches = Branch.query.all()

    return render_template("super_admin/branches.html", branches=branches)


@super_admin_bp.route("/delete-branch/<int:id>")
@login_required
def delete_branch(id):
    if current_user.role != "super_admin":
        return "Unauthorized"

    branch = Branch.query.get(id)

    if branch:
        db.session.delete(branch)
        db.session.commit()
        flash("Branch deleted", "success")

    return redirect(url_for("super_admin.manage_branches"))

@super_admin_bp.route("/admins")
@login_required
def manage_admins():
    if current_user.role != "super_admin":
        return "Unauthorized"

    admins = User.query.filter_by(role="admin").all()

    return render_template("super_admin/admins.html", admins=admins)


@super_admin_bp.route("/toggle-admin/<int:id>")
@login_required
def toggle_admin(id):
    if current_user.role != "super_admin":
        return "Unauthorized"

    admin = User.query.get(id)

    if admin:
        admin.is_active = not admin.is_active
        db.session.commit()
        status = "enabled" if admin.is_active else "disabled"
        flash(f"Admin {admin.name} has been {status}", "success")

    return redirect(url_for("super_admin.manage_admins"))

@super_admin_bp.route("/students")
@login_required
def all_students():
    if current_user.role != "super_admin":
        return "Unauthorized"

    students = Student.query.all()

    return render_template("super_admin/students.html", students=students)

@super_admin_bp.route("/switch-branch/<int:branch_id>")
@login_required
def switch_branch(branch_id):
    if current_user.role != "super_admin":
        return "Unauthorized"

    # validate branch exists
    branch = Branch.query.get(branch_id)
    if not branch:
        return "Invalid branch"

    session["branch_id"] = branch_id
    session["impersonate"] = True

    flash(f"Switched to {branch.name}", "success")
    return redirect(url_for("admin.admin_dashboard"))

@super_admin_bp.route("/exit")
@login_required
def exit_impersonation():
    session.pop("branch_id", None)
    session.pop("impersonate", None)
    return redirect(url_for("super_admin.dashboard"))

@super_admin_bp.route("/set-time", methods=["POST"])
@login_required
def set_time():
    if current_user.role != "super_admin":
        return "Unauthorized"

    action = request.form.get("action")

    from datetime import datetime, timedelta

    if action == "reset":
        session.pop("fake_time", None)

    elif action == "next_month":
        now = datetime.now()
        next_month = now.replace(day=28) + timedelta(days=4)
        next_month = next_month.replace(day=1)
        session["fake_time"] = next_month.strftime("%Y-%m-%d")

    else:
        # manual date
        fake_date = request.form.get("fake_date")
        if fake_date:
            session["fake_time"] = fake_date

    return redirect(request.referrer)