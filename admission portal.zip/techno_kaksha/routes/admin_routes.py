from unicodedata import name
from flask import Blueprint, render_template, request, redirect, url_for, flash, send_file, session
from models import student
from models.db import db
from models.course import Course, Subject
from flask_login import login_required, current_user
from models.teacher import Teacher
from models.user import User
from models.class_model import Class
from models.student import Student
from models.student_class import StudentClass
from models.fee import Fee
from models.payment import Payment
from models.branch import Branch
import math
from utils.receipt import generate_receipt
from services.analytics_service import get_today_revenue, get_this_month_revenue , get_monthly_pending_total
from services.analytics_service import (
    get_total_students,
    get_total_revenue,
    get_pending_fees,
    get_total_courses,
    get_total_teachers,
)
from services.attendance_analytics import get_admin_attendance_overview
from werkzeug.security import generate_password_hash
from models.user import User
from models.student import Student
from models.course import Course
from models.installment import Installment
from datetime import datetime
from utils.receipt_no import generate_receipt_no
from utils.time_service import get_current_time

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")


# Admin Check
def admin_required():
    return current_user.role in ["admin", "super_admin"]


# ================= ADD TEACHER =================
@admin_bp.route("/add-teacher", methods=["GET", "POST"])
@login_required
def add_teacher():

    if current_user.role not in ["admin", "super_admin"]:
        return "Unauthorized"

    # ALWAYS DEFINE THIS FIRST
    teachers = Teacher.query.join(User).filter(
        User.branch_id == session.get("branch_id", current_user.branch_id)
    ).all()

    if request.method == "POST":
        name = request.form["name"]
        email = request.form["email"]
        password = request.form["password"]
        specialization = request.form["specialization"]

        user = User(
            name=name,
            email=email,
            password=generate_password_hash(password),
            role="teacher",
            branch_id=session.get("branch_id", current_user.branch_id)
        )

        db.session.add(user)
        db.session.commit()

        teacher = Teacher(
            user_id=user.id,
            specialization=specialization
        )

        db.session.add(teacher)
        db.session.commit()

        flash("Teacher added successfully", "success")

        return redirect(url_for("admin.add_teacher"))

    return render_template(
        "admin/add_teacher.html",
        teachers=teachers
    )
@admin_bp.route("/toggle-teacher/<int:teacher_id>")
@login_required
def toggle_teacher(teacher_id):
    if not admin_required():
        return "Unauthorized"

    teacher = Teacher.query.get_or_404(teacher_id)
    effective_branch_id = session.get("branch_id", current_user.branch_id)
    if current_user.role != "super_admin" and teacher.user.branch_id != effective_branch_id:
        return "Unauthorized"

    teacher.user.is_active = not teacher.user.is_active
    db.session.commit()

    return redirect(url_for("admin.add_teacher"))

@admin_bp.route("/delete-teacher/<int:teacher_id>")
@login_required
def delete_teacher(teacher_id):
    if not admin_required():
        return "Unauthorized"

    teacher = Teacher.query.get_or_404(teacher_id)
    effective_branch_id = session.get("branch_id", current_user.branch_id)
    if current_user.role != "super_admin" and teacher.user.branch_id != effective_branch_id:
        return "Unauthorized"

    db.session.delete(teacher.user)
    db.session.delete(teacher)
    db.session.commit()

    return redirect(url_for("admin.add_teacher"))

#================= ADD CLASS =================
@admin_bp.route("/add-class", methods=["GET", "POST"])
@login_required
def add_class():
    if not admin_required():
        return "Unauthorized"

    branch_id = session.get("branch_id", current_user.branch_id)

    teachers = Teacher.query.join(User).filter(
        User.branch_id == branch_id
    ).all()

    subjects = Subject.query.all()

    # GET CLASSES OF THIS BRANCH
    classes = Class.query.filter_by(branch_id=branch_id).all()

    # COUNT STUDENTS IN EACH CLASS
    class_data = []

    for c in classes:
        student_count = StudentClass.query.filter_by(class_id=c.id).count()

        class_data.append({
            "class": c,
            "students": student_count
        })

    #  TODAY CLASS COUNT (simple for now)
    today_classes = len(classes)

    if request.method == "POST":
        subject_id = request.form["subject_id"]
        teacher_id = request.form["teacher_id"]
        timing = request.form["timing"]

        new_class = Class(
            subject_id=subject_id,
            teacher_id=teacher_id,
            branch_id=branch_id,
            timing=timing
        )

        db.session.add(new_class)
        db.session.commit()

        flash("Class created", "success")
        return redirect(url_for("admin.add_class"))

    return render_template(
        "admin/add_class.html",
        teachers=teachers,
        subjects=subjects,
        classes=class_data,
        today_classes=today_classes
    )

# ================= ADMIN DASHBOARD =================
@admin_bp.route("/dashboard")
@login_required
def admin_dashboard():

    # ROLE CHECK
    if current_user.role not in ["admin", "super_admin"]:
        return "Unauthorized"

    branch_id = session.get("branch_id", current_user.branch_id)

    # ANALYTICS DATA
    total_students = get_total_students(branch_id)
    total_revenue = get_total_revenue(branch_id)
    pending_fees = get_monthly_pending_total(branch_id)
    total_courses = get_total_courses()
    total_teachers = get_total_teachers(branch_id)
    today_revenue = get_today_revenue(branch_id)
    monthly_revenue = get_this_month_revenue(branch_id)

    # Get current branch for display
    current_branch = None
    if session.get("impersonate") and branch_id:
        current_branch = Branch.query.get(branch_id)

    return render_template(
        "admin/dashboard.html",
        total_students=total_students,
        total_revenue=total_revenue,
        pending_fees=pending_fees,
        total_courses=total_courses,
        total_teachers=total_teachers,
        today_revenue=today_revenue,
        monthly_revenue=monthly_revenue,
        current_branch=current_branch,
    )


#================= SET FEE STRUCTURE =================
@admin_bp.route("/set-fee", methods=["GET", "POST"])
@login_required
def set_fee():
    if current_user.role not in ["admin", "super_admin"]:
        return "Unauthorized"

    search = request.args.get("search")

    if search:
        students = Student.query.filter(
            Student.roll_no.like(f"%{search}%")
        ).all()
    else:
        branch_id = session.get("branch_id", current_user.branch_id)

        students = Student.query.filter_by(branch_id=branch_id).all()

    if request.method == "POST":

        student_roll_no = request.form["student_roll_no"]
        discount_type = request.form.get("discount_type", "percent")
        discount_value = float(request.form.get("discount_value", "0") or 0)
        installments = int(request.form["installments"])
        admission_fee = float(request.form["admission_fee"])

        if discount_value < 0:
            flash("Discount cannot be negative", "danger")
            return redirect(url_for("admin.set_fee"))

        student = Student.query.filter_by(roll_no=student_roll_no).first_or_404()
        if branch_id and branch_id != student.branch_id:
            return "Unauthorized"
        total_fee = student.course.total_fee

        if discount_type == "amount":
            discount_amount = min(discount_value, total_fee)
            discount_percent = (discount_amount / total_fee * 100) if total_fee else 0
        else:
            discount_percent = discount_value
            discount_amount = (discount_percent / 100) * total_fee
            if discount_amount > total_fee:
                discount_amount = total_fee

        final_fee = total_fee - discount_amount
        remaining_fee = max(0, final_fee - admission_fee)
        monthly_fee = math.ceil(remaining_fee / installments)

        # ================= CREATE / UPDATE FEE =================
        fee = Fee.query.filter_by(student_roll_no=student_roll_no).first()

        if fee:
            fee.total_fee = total_fee
            fee.discount_percent = discount_percent
            fee.discount_amount = discount_amount
            fee.final_fee = final_fee
            fee.admission_fee = admission_fee
            fee.installments = installments
            fee.monthly_fee = monthly_fee
            fee.pending_amount = final_fee - fee.paid_amount
        else:
            fee = Fee(
                student_roll_no=student_roll_no,
                total_fee=total_fee,
                discount_percent=discount_percent,
                discount_amount=discount_amount,
                final_fee=final_fee,
                admission_fee=admission_fee,
                installments=installments,
                monthly_fee=monthly_fee,
                paid_amount=0,
                pending_amount=final_fee
            )
            db.session.add(fee)

        db.session.commit()

        # ================= DELETE OLD INSTALLMENTS =================
        Installment.query.filter_by(student_roll_no=student_roll_no).delete()

        # ================= GENERATE NEW INSTALLMENTS =================
        now = get_current_time()

        # START FROM NEXT MONTH
        start_month = now.month + 1
        start_year = now.year

        if start_month > 12:
            start_month = 1
            start_year += 1

        for i in range(installments):
            month = (start_month + i - 1) % 12 + 1
            year = start_year + ((start_month + i - 1) // 12)

            due_date = datetime(year, month, 10)  # 10th of each month

            inst = Installment(
                student_roll_no=student_roll_no,
                month=month,
                year=year,
                amount=monthly_fee,
                due_date=due_date
            )

            db.session.add(inst)

        db.session.commit()

        flash("Fee + Installments created successfully", "success")

    return render_template("admin/set_fee.html", students=students)

#================= ADD PAYMENT =================
@admin_bp.route("/add-payment", methods=["GET", "POST"])
@login_required
def add_payment():

    if current_user.role not in ["admin", "super_admin"]:
        return "Unauthorized"

    from models.installment import Installment
    from datetime import datetime
    from services.fine_service import apply_fine

    search = request.args.get("search")

    # GET STUDENTS
    branch_id = session.get("branch_id", current_user.branch_id)

    if search:
        students = Student.query.filter(
            Student.roll_no.like(f"%{search}%")
        ).all()
    else:
        students = Student.query.filter_by(branch_id=branch_id).all()

    # HANDLE PAYMENT
    if request.method == "POST":
        student_roll_no = request.form["student_roll_no"]
        student = Student.query.filter_by(roll_no=student_roll_no).first_or_404()

        if branch_id and branch_id != student.branch_id:
            return "Unauthorized"
        
        payment_type = request.form.get("payment_type")
        manual_receipt_no = request.form.get("manual_receipt_no", "").strip()
        
        if not manual_receipt_no:
            flash("Manual receipt number is required", "danger")
            return redirect(url_for("admin.add_payment"))
        
        receipt_no = generate_receipt_no(student_roll_no)

        # DUPLICATE CHECK
        existing = Payment.query.filter_by(receipt_no=receipt_no).first()
        if existing:
            flash("Receipt number already exists", "danger")
            return redirect(url_for("admin.add_payment"))

        fee = Fee.query.filter_by(student_roll_no=student_roll_no).first()

        if not fee:
            flash("Fee not set", "danger")
            return redirect(url_for("admin.add_payment"))

        now = get_current_time()

        #  FORCE ADMISSION FIRST
        admission_payment = Payment.query.filter_by(
            student_roll_no=student_roll_no,
            payment_type="admission"
        ).first()

        if payment_type == "monthly" and not admission_payment:
            flash("Please pay admission first", "danger")
            return redirect(url_for("admin.add_payment"))

        installment = Installment.query.filter_by(
            student_roll_no=student_roll_no,
            month=now.month,
            year=now.year
        ).first()

        if payment_type == "admission":

            admission_payment = Payment.query.filter_by(
                student_roll_no=student_roll_no,
                payment_type="admission"
            ).first()
        
            if admission_payment:
                flash("Admission already paid", "warning")
                return redirect(url_for("admin.add_payment"))
        
            amount = fee.admission_fee

        else:
            if not installment:
                flash("No installment found for this month", "danger")
                return redirect(url_for("admin.add_payment"))

            # APPLY FINE
            installment = apply_fine(installment)

            if installment.status == "paid":
                flash("Already paid", "warning")
                return redirect(url_for("admin.add_payment"))

            base_amount = installment.amount - installment.paid_amount
            fine = installment.fine_amount

            amount = base_amount + fine

            # UPDATE INSTALLMENT
            installment.paid_amount += base_amount

            if installment.paid_amount >= installment.amount:
                installment.status = "paid"
                installment.fine_amount = 0

        payment = Payment(
            student_roll_no=student_roll_no,
            amount=amount,
            payment_type=payment_type,
            receipt_no=receipt_no,
            manual_receipt_no=manual_receipt_no,
            installment_id=installment.id if payment_type != "admission" else None
        )

        fee.paid_amount += amount
        fee.pending_amount -= amount

        db.session.add(payment)
        db.session.commit()

        flash(f"₹{amount} payment added", "success")
        return redirect(url_for("admin.add_payment"))

    # PREPARE ADMISSION-PENDING STUDENT CARDS
    now = get_current_time()

    students_with_pending = []
    monthly_payment_rows = []
    status_filter = request.args.get("status", "all")

    for s in students:
        fee = Fee.query.filter_by(student_roll_no=s.roll_no).first()
        admission_payment = Payment.query.filter_by(
            student_roll_no=s.roll_no,
            payment_type="admission"
        ).first()

        # Admission pending cards
        if fee and not admission_payment:
            students_with_pending.append({
                "student": s,
                "pending": fee.admission_fee,
                "installment": None,
                "admission_paid": False
            })

        # Monthly payment table rows (only after admission is paid)
        if fee and admission_payment:
            installment = Installment.query.filter_by(
                student_roll_no=s.roll_no,
                month=now.month,
                year=now.year
            ).first()

            if installment:
                installment = apply_fine(installment)
                status = installment.status or "pending"
                due_amount = 0 if status == "paid" else (installment.amount - installment.paid_amount + installment.fine_amount)

                last_payment = Payment.query.filter_by(
                    student_roll_no=s.roll_no,
                    payment_type="monthly",
                    installment_id=installment.id
                ).order_by(Payment.date.desc()).first()

                payment_date = last_payment.date.strftime("%d-%m-%Y") if last_payment else None

                monthly_payment_rows.append({
                    "student": s,
                    "installment": installment,
                    "due_amount": due_amount,
                    "status": status,
                    "payment_date": payment_date
                })

    if status_filter in ["paid", "pending"]:
        monthly_payment_rows = [row for row in monthly_payment_rows if row["status"] == status_filter]

    return render_template(
        "admin/add_payment.html",
        students=students_with_pending,
        monthly_rows=monthly_payment_rows,
        status_filter=status_filter
    )

#================= PAYMENT HISTORY =================
@admin_bp.route("/payment-history")
@login_required
def payment_history():
    if current_user.role not in ["admin", "super_admin"]:
        return "Unauthorized"

    branch_id = session.get("branch_id", current_user.branch_id)
    search = request.args.get("search")

    query = Payment.query.join(Student, Student.roll_no == Payment.student_roll_no)
    query = query.filter(Student.branch_id == branch_id)

    if search:
        query = query.filter(Student.roll_no.like(f"%{search}%"))

    payments = query.order_by(Payment.date.desc()).all()

    return render_template(
        "admin/payment_history.html",
        payments=payments,
        search=search
    )

#================= DOWNLOAD RECEIPT =================
@admin_bp.route("/download-receipt/<receipt_no>")
@login_required
def download_receipt(receipt_no):

    payment = Payment.query.filter_by(receipt_no=receipt_no).first()

    if not payment:
        return "Payment not found"

    student = Student.query.filter_by(roll_no=payment.student_roll_no).first()
    fee = Fee.query.filter_by(student_roll_no=student.roll_no).first()

    #  SECURITY
    if current_user.role == "student":
        if student.user_id != current_user.id:
            return "Unauthorized"

    pdf = generate_receipt(payment, student, fee)

    return send_file(
        pdf,
        as_attachment=True,
        download_name=f"receipt_{payment.receipt_no}.pdf",
        mimetype="application/pdf"
    )

@admin_bp.route("/students")
@login_required
def students():
    if not admin_required():
        return "Unauthorized"

    branch_id = session.get("branch_id", current_user.branch_id)

    query = Student.query.filter_by(branch_id=branch_id)

    search = request.args.get("search")
    if search:
        query = query.filter(Student.roll_no.like(f"%{search}%"))

    students = []

    for student in query.all():
        fee = Fee.query.filter_by(student_roll_no=student.roll_no).first()

        eligible = False
        pending = 0

        if fee:
            eligible = fee.paid_amount >= fee.admission_fee
            pending = fee.pending_amount

        students.append({
            "data": student,
            "eligible": eligible,
            "pending": pending
        })

    return render_template("admin/students.html", students=students)

@admin_bp.route("/add-student", methods=["GET", "POST"])
@login_required
def add_student():
    if not admin_required():
        return "Unauthorized"

    branch_id = session.get("branch_id", current_user.branch_id)
    courses = Course.query.filter_by(branch_id=branch_id).all()

    if request.method == "POST":

        # BASIC
        name = request.form["full_name"]
        email = request.form["email"]
        password = request.form["password"]

        # EXTRA
        dob = request.form.get("dob")
        gender = request.form.get("gender")
        guardian = request.form.get("guardian_name")
        nationality = request.form.get("nationality")
        contact = request.form.get("contact_no")
        whatsapp = request.form.get("whatsapp_no")
        course_id = request.form.get("course_id")

        # PHOTO UPLOAD
        photo_file = request.files.get("photo")
        photo_filename = None

        if photo_file and photo_file.filename != "":
            import os
            upload_path = "static/uploads"
            os.makedirs(upload_path, exist_ok=True)

            photo_filename = f"{email}_{photo_file.filename}"
            photo_file.save(os.path.join(upload_path, photo_filename))

        # CREATE USER
        user = User(
            name=name,
            email=email,
            password=generate_password_hash(password),
            role="student",
            branch_id=branch_id
        )

        db.session.add(user)
        db.session.commit()

# AUTO ROLL NUMBER - Sequential per branch/course
        from utils.generate_roll import generate_roll_no
        roll_no = generate_roll_no(branch_id, course_id)

        from datetime import datetime

        student = Student(
            user_id=user.id,
            roll_no=roll_no,
            full_name=name,
            dob=datetime.strptime(dob, "%Y-%m-%d") if dob else None,
            gender=gender,
            guardian_name=guardian,
            nationality=nationality,
            email=email,
            contact_no=contact,
            whatsapp_no=whatsapp,
            branch_id=branch_id,
            photo=photo_filename,
            course_id=course_id,
            admission_date=datetime.now().date()
        )

        db.session.add(student)
        db.session.commit()


        flash("Student added successfully", "success")
        return redirect(url_for("admin.students"))

    return render_template("admin/add_student.html", courses=courses)

@admin_bp.route("/assign-student", methods=["GET", "POST"])
@login_required
def assign_student():
    if not admin_required():
        return "Unauthorized"

    branch_id = session.get("branch_id", current_user.branch_id)

    students = Student.query.filter_by(branch_id=branch_id).all()
    classes = Class.query.filter_by(branch_id=branch_id).all()

    if request.method == "POST":
        student_roll_no = request.form["student_roll_no"]
        class_id = request.form["class_id"]

        fee = Fee.query.filter_by(student_roll_no=student_roll_no).first()

        if not fee or fee.paid_amount < fee.admission_fee:
            flash("Student not eligible", "danger")
            return redirect(url_for("admin.assign_student"))

        mapping = StudentClass(
            student_roll_no=student_roll_no,
            class_id=class_id
        )

        db.session.add(mapping)
        db.session.commit()

        flash("Assigned successfully", "success")
        return redirect(url_for("admin.assign_student"))

    return render_template(
        "admin/assign_student.html",
        students=students,
        classes=classes
    )

@admin_bp.route("/attendance-overview")
@login_required
def attendance_overview():

    if current_user.role not in ["admin", "super_admin"]:
        return "Unauthorized"

    branch_id = session.get("branch_id", current_user.branch_id)

    data = get_admin_attendance_overview(branch_id)

    #  PREPARE CHART DATA
    labels = []
    values = []

    for c in data["classes"]:
        labels.append(f"Class {c['class'].id}")
        values.append(c["percentage"])

    #  ADD THIS
    top_student = data.get("top_student")

    return render_template(
        "admin/attendance_overview.html",
        classes=data["classes"],
        low_students=data["low_students"],
        chart_labels=labels,
        chart_values=values,
        top_student=top_student
    )
