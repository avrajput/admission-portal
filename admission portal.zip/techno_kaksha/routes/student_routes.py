from flask import Blueprint, render_template, request, redirect, url_for, flash,send_file, make_response    
from flask_login import login_required, current_user
from models.student import Student
from models.fee import Fee
from models.payment import Payment
from models.attendance import Attendance
from models.student_class import StudentClass
from models.class_model import Class
from datetime import datetime
from utils.receipt import generate_receipt
from services.attendance_analytics import get_student_attendance_summary, get_subject_wise_attendance
from utils.qr import generate_qr
# from weasyprint import HTML
from sqlalchemy.orm import joinedload


student_bp = Blueprint("student", __name__, url_prefix="/student")


# ================= DASHBOARD =================
@student_bp.route("/dashboard")
@login_required
def student_dashboard():
    if current_user.role != "student":
        return "Unauthorized"

    student = Student.query.filter_by(user_id=current_user.id).first()

    if not student:
        flash("Student profile not found. Please contact admin.", "danger")
        return redirect(url_for("home"))

    mappings = StudentClass.query.filter_by(student_roll_no=student.roll_no).all()

    classes = []
    for m in mappings:
        c = Class.query.get(m.class_id)
        if c:
            classes.append({
                "subject": c.subject.name,
                "timing": c.timing,
                "status": m.status
            })

    attendance = Attendance.query.filter_by(student_roll_no=student.roll_no)\
        .order_by(Attendance.date.desc())\
        .limit(5).all()

    return render_template(
        "student/dashboard.html",
        classes=classes,
        attendance=attendance
    )


# ================= FEES =================
@student_bp.route("/fees")
@login_required
def student_fees():
    if current_user.role != "student":
        return "Unauthorized"

    from models.installment import Installment
    from datetime import datetime

    student = Student.query.filter_by(user_id=current_user.id).first()
    if not student:
        return "Student not found"

    fee = Fee.query.filter_by(student_roll_no=student.roll_no).first()
    payments = Payment.query.filter_by(student_roll_no=student.roll_no).all()

    now = datetime.now()

    installment = Installment.query.filter_by(
        student_roll_no=student.roll_no,
        month=now.month,
        year=now.year
    ).first()

    return render_template(
        "student/fees.html",
        fee=fee,
        payments=payments,
        installment=installment
    )

# ================= ATTENDANCE =================
@student_bp.route("/attendance")
@login_required
def student_attendance():

    if current_user.role != "student":
        return "Unauthorized"

    student = Student.query.filter_by(user_id=current_user.id).first()

    if not student:
        return "Student not found"

    overall = get_student_attendance_summary(student.roll_no)

    subject_data = get_subject_wise_attendance(student.roll_no)

    return render_template(
        "student/attendance.html",
        summary=overall,
        subjects=subject_data
    )

## ================= DOWNLOAD RECEIPT =================
@student_bp.route("/download-receipt/<receipt_no>")
@login_required
def download_receipt(receipt_no):

    payment = Payment.query.filter_by(receipt_no=receipt_no).first()
    student = Student.query.filter_by(roll_no=payment.student_roll_no).first()
    fee = Fee.query.filter_by(student_roll_no=student.roll_no).first()

    # SECURITY (important)
    if current_user.role == "student":
        if student.user_id != current_user.id:
            return "Unauthorized"

    pdf = generate_receipt(payment, student, fee)

    return send_file(
        pdf,
        as_attachment=True,
        download_name=f"receipt_{payment.receipt_no}.pdf",
        mimetype="application/pdf"
    )

@student_bp.route("/profile")
@login_required
def student_profile():

    if current_user.role != "student":
        return "Unauthorized"

    student = Student.query.filter_by(user_id=current_user.id).first()

    if not student:
        return "Student not found"

    # QR DATA (unique but stable)
    qr_data = f"http://127.0.0.1:5000/verify/{student.roll_no}"

    qr_code = generate_qr(qr_data)

    return render_template(
        "student/profile.html",
        student=student,
        qr_code=qr_code
    )

@student_bp.route("/download-id-card")
@login_required
def download_id_card():

    if current_user.role != "student":
        return "Unauthorized"

    student = Student.query.options(
        joinedload(Student.course)
    ).filter_by(user_id=current_user.id).first()

    qr_data = f"http://127.0.0.1:5000/verify/{student.roll_no}"
    qr_code = generate_qr(qr_data)

    html = render_template(
        "student/id_card_pdf.html",
        student=student,
        qr_code=qr_code
    )

    # pdf = HTML(
    #     string=html,
    #     base_url=request.url_root   # more reliable
    # ).write_pdf()

    # response = make_response(pdf)
    # response.headers["Content-Type"] = "application/pdf"
    # response.headers["Content-Disposition"] = "attachment; filename=id_card.pdf"

    # return response
    return "PDF generation temporarily disabled"
