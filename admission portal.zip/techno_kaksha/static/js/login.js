document.addEventListener('DOMContentLoaded', () => {
    const inputs = document.querySelectorAll('.login-form .form-control');

    inputs.forEach((input) => {
        const parent = input.closest('.neu-input');
        if (!parent) return;

        const updateState = () => {
            if (input.value.trim() !== '') {
                parent.classList.add('filled');
            } else {
                parent.classList.remove('filled');
            }
        };

        input.addEventListener('input', updateState);
        updateState();
    });

    const passwordToggle = document.querySelector('.password-toggle');
    if (passwordToggle) {
        const passwordInput = document.querySelector('#password');
        passwordToggle.addEventListener('click', () => {
            if (!passwordInput) return;
            const isPassword = passwordInput.type === 'password';
            passwordInput.type = isPassword ? 'text' : 'password';
            passwordToggle.innerHTML = isPassword
                ? '<i class="fa-solid fa-eye-slash"></i>'
                : '<i class="fa-solid fa-eye"></i>';
        });
    }
});
