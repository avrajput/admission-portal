from models.db import db
from models.branch import Branch

course_subject = db.Table('course_subject',
    db.Column('course_id', db.Integer, db.ForeignKey('courses.id')),
    db.Column('subject_id', db.Integer, db.ForeignKey('subjects.id'))
)


class Course(db.Model):
    __tablename__ = "courses"
    __table_args__ = (
        db.UniqueConstraint('name', 'branch_id', name='uq_course_branch'),
    )

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    duration = db.Column(db.Integer)
    total_fee = db.Column(db.Float)
    branch_id = db.Column(db.Integer, db.ForeignKey('branches.id'))
    branch = db.relationship('Branch')

    subjects = db.relationship(
        "Subject",
        secondary=course_subject,
        backref="courses"
    )


class Subject(db.Model):
    __tablename__ = "subjects"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))