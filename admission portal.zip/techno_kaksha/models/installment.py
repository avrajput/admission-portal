from models.db import db
from datetime import datetime

class Installment(db.Model):
    __tablename__ = "installments"

    id = db.Column(db.Integer, primary_key=True)

    student_roll_no = db.Column(db.String(50), db.ForeignKey("students.roll_no"))

    month = db.Column(db.Integer)
    year = db.Column(db.Integer)

    amount = db.Column(db.Float)
    paid_amount = db.Column(db.Float, default=0)

    due_date = db.Column(db.DateTime)   # NEW
    fine_amount = db.Column(db.Float, default=0)  # NEW

    status = db.Column(db.String(20), default="pending")  # pending / paid / overdue

    student = db.relationship("Student", foreign_keys="Installment.student_roll_no")
