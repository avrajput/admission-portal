from models.db import db
import math

class Fee(db.Model):
    __tablename__ = "fees"

    id = db.Column(db.Integer, primary_key=True)
    student_roll_no = db.Column(db.String(50), db.ForeignKey("students.roll_no"))

    total_fee = db.Column(db.Float)

    discount_percent = db.Column(db.Float)
    discount_amount = db.Column(db.Float)

    final_fee = db.Column(db.Float)

    installments = db.Column(db.Integer) 
    admission_fee = db.Column(db.Float, default=0)
    monthly_fee = db.Column(db.Float)

    paid_amount = db.Column(db.Float, default=0)
    pending_amount = db.Column(db.Float)

    student = db.relationship("Student", backref="fee", foreign_keys="Fee.student_roll_no")
