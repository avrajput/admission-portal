from models.db import db

class Teacher(db.Model):
    __tablename__ = "teachers"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    specialization = db.Column(db.String(100))

    user = db.relationship("User", backref="teacher")