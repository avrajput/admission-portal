from models.db import db
from datetime import datetime

class Payment(db.Model):
    __tablename__ = "payments"

    receipt_no = db.Column(db.String(50), primary_key=True)

    student_roll_no = db.Column(db.String(50), db.ForeignKey("students.roll_no"))
    amount = db.Column(db.Float)
    payment_type = db.Column(db.String(50))  # admission / monthly
    date = db.Column(db.DateTime, default=datetime.utcnow)
    
    manual_receipt_no = db.Column(db.String(50))  # Secondary receipt no for manual slips
    
    installment_id = db.Column(db.Integer, db.ForeignKey("installments.id"))
    installment = db.relationship("Installment")
    
    student = db.relationship("Student", backref="payments", foreign_keys="Payment.student_roll_no")
