from models.db import db


class Student(db.Model):
    __tablename__ = "students"

    roll_no = db.Column(db.String(50), primary_key=True)

    user_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    user = db.relationship("User", backref="student")

    full_name = db.Column(db.String(100))
    dob = db.Column(db.Date)
    gender = db.Column(db.String(20))

    guardian_name = db.Column(db.String(100))
    nationality = db.Column(db.String(50))

    email = db.Column(db.String(100))
    contact_no = db.Column(db.String(15))
    whatsapp_no = db.Column(db.String(15))

    branch_id = db.Column(db.Integer, db.ForeignKey("branches.id"))
    branch = db.relationship("Branch")

    photo = db.Column(db.String(200))

    course_id = db.Column(db.Integer, db.ForeignKey("courses.id"))
    course = db.relationship("Course")

    admission_date = db.Column(db.Date)

    status = db.Column(db.String(50), default="active")