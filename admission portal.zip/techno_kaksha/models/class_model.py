from models.db import db

class Class(db.Model):
    __tablename__ = "classes"

    id = db.Column(db.Integer, primary_key=True)
    subject_id = db.Column(db.Integer, db.ForeignKey("subjects.id"))
    teacher_id = db.Column(db.Integer, db.ForeignKey("teachers.id"))
    branch_id = db.Column(db.Integer, db.ForeignKey("branches.id"))
    branch = db.relationship("Branch")
    timing = db.Column(db.String(50))

    subject = db.relationship("Subject")
    teacher = db.relationship("Teacher")