from models.db import db

class StudentClass(db.Model):
    __tablename__ = "student_classes"

    id = db.Column(db.Integer, primary_key=True)
    student_roll_no = db.Column(db.String(50), db.ForeignKey("students.roll_no"))
    class_id = db.Column(db.Integer, db.ForeignKey("classes.id"))
    status = db.Column(db.String(50), default="ongoing")