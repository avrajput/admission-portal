from models.db import db
from datetime import datetime

class Attendance(db.Model):
    __tablename__ = "attendance"

    id = db.Column(db.Integer, primary_key=True)

    student_roll_no = db.Column(db.String(50), db.ForeignKey("students.roll_no"))
    class_id = db.Column(db.Integer, db.ForeignKey("classes.id"))

    date = db.Column(db.Date, default=datetime.utcnow().date)

    status = db.Column(db.String(20))  # present / absent

    student = db.relationship("Student", foreign_keys="Attendance.student_roll_no")
    class_obj = db.relationship("Class")