from models.attendance import Attendance
from models.class_model import Class
from models.course import Subject
from models.student import Student
from models.db import db


def get_student_attendance_summary(student_roll_no, class_id=None):
    """
    Returns:
    {
        total: int,
        present: int,
        absent: int,
        percentage: float
    }
    """

    query = Attendance.query.filter_by(student_roll_no=student_roll_no)

    if class_id:
        query = query.filter_by(class_id=class_id)

    total = query.count()

    present = query.filter_by(status="present").count()
    absent = query.filter_by(status="absent").count()

    percentage = (present / total * 100) if total > 0 else 0

    return {
        "total": total,
        "present": present,
        "absent": absent,
        "percentage": round(percentage, 2)
    }

def get_subject_wise_attendance(student_roll_no):

    # JOIN attendance → class → subject
    records = db.session.query(
        Class.subject_id,
        db.func.count(Attendance.id).label("total"),
        db.func.sum(
            db.case(
                (Attendance.status == "present", 1),
                else_=0
            )
        ).label("present")
    ).join(Class, Attendance.class_id == Class.id)\
     .filter(Attendance.student_roll_no == student_roll_no)\
     .group_by(Class.subject_id)\
     .all()

    result = []

    for r in records:
        total = r.total or 0
        present = r.present or 0
        percentage = (present / total * 100) if total > 0 else 0

        subject = Subject.query.get(r.subject_id)

        result.append({
            "subject": subject.name if subject else "Unknown",
            "total": total,
            "present": present,
            "percentage": round(percentage, 2)
        })

    return result

def get_admin_attendance_overview(branch_id=None):
    
    # CLASS-WISE AVG
    class_query = db.session.query(
        Class.id,
        db.func.count(Attendance.id).label("total"),
        db.func.sum(
            db.case(
                (Attendance.status == "present", 1),
                else_=0
            )
        ).label("present")
    ).join(Attendance, Attendance.class_id == Class.id)

    if branch_id:
        class_query = class_query.filter(Class.branch_id == branch_id)

    class_stats = class_query.group_by(Class.id).all()

    class_data = []

    for c in class_stats:
        total = c.total or 0
        present = c.present or 0
        percentage = (present / total * 100) if total > 0 else 0

        class_obj = Class.query.get(c.id)

        class_data.append({
            "class": class_obj,
            "percentage": round(percentage, 2)
        })

    # LOW ATTENDANCE STUDENTS (< 50%)
    student_query = db.session.query(
        Student.roll_no,
        db.func.count(Attendance.id).label("total"),
        db.func.sum(
            db.case(
                (Attendance.status == "present", 1),
                else_=0
            )
        ).label("present")
    ).join(Attendance, Attendance.student_roll_no == Student.roll_no)

    if branch_id:
        student_query = student_query.filter(Student.branch_id == branch_id)

    student_stats = student_query.group_by(Student.roll_no).all()

    low_students = []

    for s in student_stats:
        total = s.total or 0
        present = s.present or 0
        percentage = (present / total * 100) if total > 0 else 0

        if percentage < 50:
            student = Student.query.get(s.roll_no)

            low_students.append({
                "student": student,
                "percentage": round(percentage, 2)
            })

    # TOP STUDENT (HIGHEST ATTENDANCE)
    top_student = None
    highest = 0

    for s in student_stats:
        total = s.total or 0
        present = s.present or 0
        percentage = (present / total * 100) if total > 0 else 0

        if percentage > highest:
            highest = percentage
            student = Student.query.get(s.roll_no)

            top_student = {
                "student": student,
                "percentage": round(percentage, 2)
            }
    return {
        "classes": class_data,
        "low_students": low_students,
        "top_student": top_student
    }
