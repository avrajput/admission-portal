from models.student import Student
from models.user import User
from models.payment import Payment
from models.fee import Fee
from models.course import Course
from models.teacher import Teacher
from models.db import db
from datetime import datetime
from utils.time_service import get_current_time


def get_total_students(branch_id):
    return Student.query.filter(Student.branch_id == branch_id).count()


def get_total_revenue(branch_id):
    result = db.session.query(db.func.sum(Payment.amount))\
        .join(Student)\
        .filter(Student.branch_id == branch_id)\
        .scalar()

    return result or 0


def get_pending_fees(branch_id):
    result = db.session.query(db.func.sum(Fee.pending_amount))\
        .join(Student)\
        .join(User)\
        .filter(User.branch_id == branch_id)\
        .scalar()

    return result or 0


def get_total_courses():
    return Course.query.count()


def get_total_teachers(branch_id):
    return Teacher.query.join(User).filter(
        User.branch_id == branch_id
    ).count()

def get_monthly_pending_total(branch_id):
    from models.installment import Installment

    now = get_current_time()

    result = db.session.query(
        db.func.sum(Installment.amount - Installment.paid_amount)
    ).join(Student)\
     .join(User)\
     .filter(User.branch_id == branch_id)\
     .filter(Installment.month == now.month)\
     .filter(Installment.year == now.year)\
     .scalar()

    return result or 0

def get_today_revenue(branch_id):
    today = datetime.today().date()

    result = db.session.query(db.func.sum(Payment.amount))\
        .join(Student)\
        .join(User)\
        .filter(User.branch_id == branch_id)\
        .filter(db.func.date(Payment.date) == today)\
        .scalar()

    return result or 0


def get_this_month_revenue(branch_id):
    now = get_current_time()

    result = db.session.query(db.func.sum(Payment.amount))\
        .join(Student)\
        .join(User)\
        .filter(User.branch_id == branch_id)\
        .filter(db.extract('month', Payment.date) == now.month)\
        .filter(db.extract('year', Payment.date) == now.year)\
        .scalar()

    return result or 0