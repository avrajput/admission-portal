from datetime import datetime

from utils.time_service import get_current_time

def apply_fine(installment):  # No student_id param needed; works on installment instance
    now = get_current_time()

    if installment.status == "paid":
        return installment

    if now > installment.due_date:
        days_late = (now - installment.due_date).days

        fine = days_late * 10  # ₹10 per day

        installment.fine_amount = fine
        installment.status = "overdue"

    return installment