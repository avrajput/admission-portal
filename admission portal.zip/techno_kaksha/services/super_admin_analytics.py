from models.db import db
from models.branch import Branch
from models.student import Student
from models.payment import Payment
from models.user import User


def get_super_admin_stats():
    total_branches = Branch.query.count()
    total_students = Student.query.count()
    total_admins = User.query.filter_by(role="admin").count()

    total_revenue = db.session.query(db.func.sum(Payment.amount)).scalar() or 0

    return {
        "total_branches": total_branches,
        "total_students": total_students,
        "total_admins": total_admins,
        "total_revenue": total_revenue
    }


def get_branch_wise_data():
    branches = Branch.query.all()

    data = []

    for b in branches:
        students = Student.query.filter(Student.branch_id == b.id).count()

        revenue = db.session.query(db.func.sum(Payment.amount))\
            .join(Student)\
            .filter(Student.branch_id == b.id)\
            .scalar() or 0

        data.append({
            "branch": b,
            "students": students,
            "revenue": revenue
        })

    return data

def get_branch_insights():
    data = get_branch_wise_data()

    if not data:
        return None, None

    top = max(data, key=lambda x: x["revenue"])
    low = min(data, key=lambda x: x["revenue"])

    return top, low

def get_monthly_revenue():
    from models.payment import Payment
    from sqlalchemy import func
    from datetime import datetime

    year = datetime.now().year

    data = (
        db.session.query(
            func.month(Payment.date),
            func.sum(Payment.amount)
        )
        .filter(func.year(Payment.date) == year)
        .group_by(func.month(Payment.date))
        .all()
    )

    months = [0]*12

    for month, revenue in data:
        months[month-1] = revenue

    return months